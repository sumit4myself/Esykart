
package com.acn.avs.api.common.service.impl;

import java.util.List;

import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;

import com.acn.avs.api.common.service.CrudServiceWithSearch;
import com.acn.avs.api.common.service.client.CrudServiceClientWithSearch;
import com.acn.avs.common.model.SearchFilter;

public abstract class CrudServiceWithSearchImpl<T> implements CrudServiceWithSearch<T> {

	@Override
	public ResponseEntity<Void> save(T entity) {
		return getServiceClientWithSearch().save(entity);
	}

	@Override
	public ResponseEntity<Void> update(Integer id, T entity) {
		return getServiceClientWithSearch().update(id, entity);
	}

	@Override
	public ResponseEntity<Void> updatePartially(Integer id, T entity) {
		return getServiceClientWithSearch().updatePartially(id, entity);
	}

	@Override
	public ResponseEntity<Void> delete(Integer id) {
		return getServiceClientWithSearch().delete(id);
	}

	@Override
	public ResponseEntity<Resource<T>> find(Integer id, String projection) {
		return getServiceClientWithSearch().find(id, projection);
	}

	@Override
	public ResponseEntity<PagedResources<Resource<T>>> findAll(Integer page, Integer size,
			List<String> sort, String projection) {
		return getServiceClientWithSearch().findAll(page, size, sort, projection);
	}

	@Override
	public ResponseEntity<PagedResources<Resource<T>>> search(SearchFilter filter) {
		return getServiceClientWithSearch().search(filter);
	}

	protected abstract CrudServiceClientWithSearch<T> getServiceClientWithSearch();

}
