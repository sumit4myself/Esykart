
package com.acn.avs.api.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.feign.FeignAutoConfiguration;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScan.Filter;
import org.springframework.context.annotation.FilterType;

import com.acn.avs.api.netflix.feign.EnableCustomizableFeignClients;

@EnableHystrix
@SpringBootApplication
@EnableAutoConfiguration(exclude = FeignAutoConfiguration.class)
@ComponentScan(
		basePackages = { "com.acn.avs.api" }, 
		excludeFilters = {@Filter(type = FilterType.REGEX, 
			pattern = {"com.acn.avs.api.common.service.client.*Client*","com.acn.avs.api.*.service.client..*" }
		) 
})
@EnableCustomizableFeignClients(basePackages = { "com.acn.avs.api" })
public class APIGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(APIGatewayApplication.class, args);
	}

}
