package com.acn.avs.api.common.service;

import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;


public interface CrudService<T> {

	ResponseEntity<Void> save(T entity);

	ResponseEntity<Void> update(Integer id, T entity);

	ResponseEntity<Void> updatePartially(Integer id, T entity);

	ResponseEntity<Void> delete(Integer id);

	ResponseEntity<Resource<T>> find(Integer id,String projection);

}
