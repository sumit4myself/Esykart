package com.acn.avs.api.product.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.acn.avs.api.common.service.client.CrudServiceClientWithSearch;
import com.acn.avs.api.common.service.impl.CrudServiceWithSearchImpl;
import com.acn.avs.api.product.service.STBService;
import com.acn.avs.api.product.service.client.STBServiceClient;
import com.acn.avs.api.stb.model.STBModel;


@Service
public class STBServiceImpl
		extends CrudServiceWithSearchImpl<STBModel>
		implements STBService {

	@Autowired
	private STBServiceClient client;

	

	



	/* (non-Javadoc)
	 * @see com.acn.avs.api.common.service.impl.CrudServiceWithSearchImpl#getServiceClientWithSearch()
	 */
	@Override
	protected CrudServiceClientWithSearch<STBModel> getServiceClientWithSearch() {
		// TODO Auto-generated method stub
		return null;
	}

}
