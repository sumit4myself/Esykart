package com.acn.avs.api.config;

import org.springframework.context.annotation.Configuration;


@Configuration
public class SpringBeanConfiguration {

	
}
