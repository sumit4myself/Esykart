package com.acn.avs.api.common.service.client;

import java.util.List;

import org.springframework.hateoas.MediaTypes;
import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.acn.avs.common.model.SearchFilter;


public interface CrudServiceClientWithSearch<T> {

	@RequestMapping(method = RequestMethod.POST, consumes = {
		MediaType.APPLICATION_JSON_VALUE })
	ResponseEntity<Void> save(T entity);

	@RequestMapping(value = "/{id}", method = RequestMethod.PUT, consumes = {
		MediaType.APPLICATION_JSON_UTF8_VALUE })
	ResponseEntity<Void> update(@PathVariable("id") Integer id, T entiy);

	@RequestMapping(value = "{id}", method = RequestMethod.PATCH, consumes = {
		"application/merge-patchjson;charset=UTF-8" })
	ResponseEntity<Void> updatePartially(@PathVariable("id") Integer id, T entity);

	@RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
	ResponseEntity<Void> delete(@PathVariable("id") Integer id);

	@RequestMapping(value = "/{id}", method = RequestMethod.GET, produces = {
		MediaTypes.HAL_JSON_VALUE })
	ResponseEntity<Resource<T>> find(@PathVariable("id") Integer id,
			@RequestParam("projection") String projection);

	@RequestMapping(method = RequestMethod.GET, produces = { MediaTypes.HAL_JSON_VALUE })
	ResponseEntity<PagedResources<Resource<T>>> findAll(
			@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "size", required = false) Integer size,
			@RequestParam(value = "sort", required = false) List<String> sort,
			@RequestParam(value = "projection", required = false) String projection);

	@RequestMapping(value = "/search", method = RequestMethod.POST, consumes = {
		MediaType.APPLICATION_JSON_VALUE}, produces = {
			MediaTypes.HAL_JSON_VALUE })
	ResponseEntity<PagedResources<Resource<T>>> search(SearchFilter filter);

}
