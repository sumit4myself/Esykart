
package com.acn.avs.api.common.service;

import java.util.List;

import org.springframework.hateoas.PagedResources;
import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;

import com.acn.avs.common.model.SearchFilter;

public interface CrudServiceWithSearch<T> extends CrudService<T> {

	ResponseEntity<PagedResources<Resource<T>>> findAll(Integer page, Integer size,
			List<String> sort, String projection);

	ResponseEntity<PagedResources<Resource<T>>> search(SearchFilter filter);
}
