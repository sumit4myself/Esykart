package com.acn.avs.api.stb.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.acn.avs.api.common.rest.controller.CrudControllerWithSearch;
import com.acn.avs.api.common.service.CrudService;
import com.acn.avs.api.product.service.STBService;
import com.acn.avs.api.stb.model.STBModel;

@RestController
@RequestMapping("stb")
public class STBRestController
		extends CrudControllerWithSearch<STBModel> {

	@Autowired
	private STBService service;

	
	@Override
	protected CrudService<STBModel> getService() {
		return service;
	}

}
