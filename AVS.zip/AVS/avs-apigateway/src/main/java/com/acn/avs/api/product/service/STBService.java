package com.acn.avs.api.product.service;

import com.acn.avs.api.common.service.CrudServiceWithSearch;
import com.acn.avs.api.stb.model.STBModel;


public interface STBService extends CrudServiceWithSearch<STBModel> {

	

}