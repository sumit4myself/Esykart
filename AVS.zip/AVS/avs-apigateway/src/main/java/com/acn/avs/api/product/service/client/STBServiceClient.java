package com.acn.avs.api.product.service.client;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

import com.acn.avs.api.common.service.client.CrudServiceClientWithSearch;
import com.acn.avs.api.stb.model.STBModel;
import com.acn.avs.services.Services;


@RequestMapping("/stb")
@FeignClient(Services.STB_SERVICE)
public interface STBServiceClient extends CrudServiceClientWithSearch<STBModel> {

}
