package com.acn.avs.api.common.service.impl;

import org.springframework.hateoas.Resource;
import org.springframework.http.ResponseEntity;

import com.acn.avs.api.common.service.CrudService;
import com.acn.avs.api.common.service.client.CrudServiceClient;


public abstract class CrudServiceImpl<T> implements CrudService<T> {

	@Override
	public ResponseEntity<Void> save(T entity) {
		return getServiceClient().save(entity);
	}

	@Override
	public ResponseEntity<Void> update(Integer id, T entity) {
		return getServiceClient().update(id, entity);
	}

	@Override
	public ResponseEntity<Void> updatePartially(Integer id, T entity) {
		return getServiceClient().updatePartially(id, entity);
	}

	@Override
	public ResponseEntity<Void> delete(Integer id) {
		return getServiceClient().delete(id);
	}

	@Override
	public ResponseEntity<Resource<T>> find(Integer id,String projection) {
		return getServiceClient().find(id,projection);
	}

	protected abstract CrudServiceClient<T> getServiceClient();

}
