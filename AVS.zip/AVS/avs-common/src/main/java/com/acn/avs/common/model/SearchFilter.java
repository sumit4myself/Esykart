/**
 * 
 */
package com.acn.avs.common.model;


/**
 * @author sumit.sharma
 *
 */
public class SearchFilter {

}
