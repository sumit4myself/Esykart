package com.acn.avs.services;

/**
 * 
 * @author Sumit Kumar Sharma
 * @since 1.0
 */
public interface Services {

	String STB_SERVICE = "STB-SERVICE";

	
}
