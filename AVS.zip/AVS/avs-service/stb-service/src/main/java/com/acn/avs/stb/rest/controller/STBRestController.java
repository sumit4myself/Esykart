
package com.acn.avs.stb.rest.controller;

import org.springframework.data.rest.webmvc.RepositoryRestController;
import org.springframework.web.bind.annotation.RequestMapping;

@RepositoryRestController
@RequestMapping(value = "/stb")
public class STBRestController {

	



}
